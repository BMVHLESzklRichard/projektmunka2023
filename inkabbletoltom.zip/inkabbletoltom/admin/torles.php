<?php
session_start();

if(!isset($_SESSION["belepett"]))
{
    header("Location: tartalom-szerkesztes.php");
}

if(isset($_GET['id']))
{
    require("../kapcsolat/kapcsproj.php");
    
    $id= (int)$_GET['id'];
    $sql = "DELETE FROM hirek 
            WHERE id = {$id}";
    
    mysqli_query($dbconn, $sql);
}
header("Location: tartalom-szerkeszto.php");
?>