<?php

use function PHPSTORM_META\map;

session_start();
if(!isset($_SESSION["belepett"]))
{
  header("Location:../false.html");  
}

if(!isset($_REQUEST["id"]))
{
  header("Location:tartalom-szerkeszto.php");  
}


if(isset($_POST["rendben"]))
{
    //változók clear
    $_POST = array_map("trim",$_POST);
    $alias = strtolower(strip_tags($_POST['alias']));

    $cim = strip_tags($_POST['cim']);
    $tartalom = $_POST['tartalom'];
    $leiras = strip_tags($_POST['leiras']);
    $kulcsszavak = strip_tags($_POST['kulcsszavak']);   
	$statusz = (int)$_POST['statusz'];


	//változók ellenőrzés
	 //ellenőrzés
	 if(empty($alias))
	 {
		 $hibak[] = "HÉJÉJÉJÉJJ ALIAS üres!";
	 }
 
	 if(!preg_match("/^[a-z_]*$/",$alias))
	 {
		 $hibak[] = "(ノಠ益ಠ)ノ彡┻━┻ dikilyenjeleketne a zaliasba!";
	 }
 
	 if(empty($cim))
	 {
		 $hibak[] = "HÉJÉJÉJÉJJ cím üres!";
	 }

	 //hibakcollect
 
	 if(isset($hibak))
	 {
		 $kimenet = "<ul>\n";
		 foreach($hibak as $hiba)
		 {
			 $kimenet.="<li>{$hiba}</li>\n";
		 }
		 $kimenet.="</ul>";
	 }
	 else
	 {

        $id= (int)$_GET['id'];
		 // mehet a levesbe(adatbázisba)
		 require("../kapcsolat/kapcsproj.php");
		 $sql = "UPDATE `hirek` SET `alias`='{$alias}',`cim`='{$cim}',`tartalom`='{$tartalom}',`modositas`=NOW(),`leiras`='{$leiras}',`kulcsszavak`='{$kulcsszavak}',`statusz`='{$statusz}' WHERE `id` = {$id}";
		 mysqli_query($dbconn, $sql);
		 header("Location: tartalom-szerkeszto.php");
	 }
}
else
{
    require("../kapcsolat/kapcsproj.php");
    $id= (int)$_GET['id'];
    $sql = "SELECT * from hirek WHERE id = {$id}";

    $eredmeny = mysqli_query($dbconn, $sql);
    $sor = mysqli_fetch_assoc($eredmeny);

    $alias = $sor['alias'];

    $cim = $sor['cim'];
    $tartalom = $sor['tartalom'];
    $leiras = $sor['leiras'];
    $kulcsszavak = $sor['kulcsszavak'];
    $statusz = $sor['statusz'];

}

$kimenet = (isset($kimenet)) ? $kimenet : "";
// $alias = (isset($alias)) ? $alias : "";

// $menunev = (isset($menunev)) ? $menunev : "";
// $tartalom  = (isset($tartalom)) ? $tartalom  : "";
// $leiras  = (isset($leiras)) ? $leiras  : "";
// $kulcsszavak = (isset($kulcsszavak)) ? $kulcsszavak : "";
// $statusz = (isset($statusz)) ? $statusz : "";

$urlap = <<<URLAP
<form action="" method="post">
	{$kimenet}
	<p>
		<label for="alias">Alias:</label><br>
		<input type="text" name="alias" id="alias" required pattern="^[a-z-_]+$" value="{$alias}">
	</p>
	
	<p>
		<label for="cim">Menünév:</label><br>
		<input type="text" name="cim" id="cim" value="{$cim}" required>
	</p>
	<p>
		<label for="tartalom">Tartalom:</label><br>
		<textarea name="tartalom" id="tartalom" value="{$tartalom}" style="min-height:300px">$tartalom</textarea>
	</p>
	<p>
		<label for="leiras">Leírás:</label><br>
	<textarea name="leiras" id="leiras" value="{$leiras}">$leiras</textarea>
	</p>
	<p>
		<label for="kulcsszavak">Kulcsszavak:</label><br>
	    <textarea name="kulcsszavak" id="kulcsszavak" value="{$kulcsszavak}">$kulcsszavak</textarea>
	</p>
	<p>
		<label for="statusz">Státusz:</label><br>
		<select name="statusz" id="statusz">
			<option value="1">Aktív</option>
			<option value="2">Aktívatlan</option>
		</select>
	</p>
	<p>
		<em>CsÁkÁnY cSiLlAgGaL mEzŐ</em>
	</p>
	<input type="submit" value="Rendben" id="rendben" name="rendben">
	<input type="reset" value="REszel">
</form>

URLAP;

$menu = "<ul>
           <li><a href=\"tartalom-szerkesztes.php\">Tartalom</a></li>
        </ul>";

//Fernando Sablonzo
$sablon = file_get_contents("sablon.html");
//mitmireholdik
$sablon = str_replace("{{menu}}",$menu,$sablon);
$sablon = str_replace("{{cim}}","Új oldal",$sablon);
$sablon = str_replace("{{tartalom}}",$urlap,$sablon);
$sablon = str_replace("{{oldalsav}}","",$sablon);

print($sablon);
?>