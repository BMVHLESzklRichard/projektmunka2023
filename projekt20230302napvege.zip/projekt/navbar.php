<nav>
        <div class="navbar">
            <i class='bx bx-menu'></i>
            <div class="logo"><a href="#"><img src="../kepek/logo2.png" alt="" class="logonk"></a>
            </div>
            <div class="nav-links" id="navkis">
                <div class="sidebar-logo">
                    <span class="logo-name">R.N.</span>
                    <div class="felhasznalokis" id="kivanbent">
                        <div class="kepbutton" onclick="userjelen()">
                            <?php
                            echo "<img src=../kpes/" . $foto . ">";
                            ?>
                            <div class="felnev">
                                <?php
                                $kivanbent
                                ?>
                            </div>
                           
                        </div>
                    </div>
                    <i class='bx bx-x'></i>
                </div>
                <ul class="links">
                    <li><a href="#">Főoldal</a></li>
                    <li id="menetelem">
                        <a href="#" id="menetrend">Menetrend</a>
                        <i class='bx bxs-chevron-down htmlcss-arrow arrow  '></i>
                    </li>
                    <li id="tabellaelem">
                        <a href="#">Tabellák</a>
                        <i class='bx bxs-chevron-down js-arrow arrow '></i>
                    </li>
                    <li><a href="#rolunk">Rólunk</a></li>
                    <li><a href="#elerthetoseg">Elérhetőségeink</a></li>
                </ul>
            </div>
            <div class="search-box">
                <i class='bx bx-search'></i>
                <div class="input-box">
                    <input type="text" placeholder="Search...">
                </div>
            </div>
            <div class="felhasznalo">
                <div class="kepbutton" onclick="userjelen()">
                    <a href="#top">
                        <?php
                        echo "<img src=../kpes/" . $foto . ">";
                        ?>
                    </a>
                    <div class="felnev">
                        <?php
                        $kivanbent
                        ?>
                    </div>
                </div>
            </div>
        </div>
    <div class="almenu" id="almenuu">
        <div class="alalmenu">
            <div class="felirat">
                <h2> <a href="teljes.php"> Teljes menetrend</a></h2>
            </div>

            <?php
            echo $futammenu;
            ?>
            <!-- <div class="elrendezes">
                <div class="kovetkezo_futam">
                    <div class="card">
                        <img src="../kepek/bahrain.png" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Bahraini Nagydíj</h5>
                            <p class="card-text">Március 03-05</p>
                        </div>
                    </div>

                  
                </div>


                <div class="nincsborder">
                    <img src="../kepek/saudi.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Szaúdi Nagydíj</h5>
                        <p class="card-text">Március 17-19</p>
                    </div>
                </div>

                <div class="nincsborder">
                    <img src="../kepek/australia.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Ausztrál Nagydíj</h5>
                        <p class="card-text">Március 30-Április 02</p>
                    </div>
                </div>
                <div class="nincsborder">
                    <img src="../kepek/azer.png" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Azeri Nagydíj</h5>
                        <p class="card-text">Április 28-30</p>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
    <div class="almenu2" id="almenuu2">
        <div class="alalmenu">
            <div class="felirat">
                <h2> <a href="teljes.php"> Teljes menetrend</a></h2>
            </div>
            <h3>...</h3>
        </div>
    </div>
    </nav>