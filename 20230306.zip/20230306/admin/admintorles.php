<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
if(!isset($_SESSION["belepett"]))
{
  header("Location:../false.html");  
}

if(isset($_GET['id']))
{
    require("../kapcsolat/kapcsproj.php");
    
    $id= (int)$_GET['id'];
    $sql = "DELETE FROM projectacc 
            WHERE id = {$id}";
    
    mysqli_query($dbconn, $sql);
}
header("Location: admin-kezelo.php");
?>