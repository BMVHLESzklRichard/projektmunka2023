<?php
header("Location: ../user/user.php");
exit();
?>