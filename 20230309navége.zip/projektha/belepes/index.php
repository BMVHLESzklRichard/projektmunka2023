<?php
header("Location: belepproj.php");
exit();
?>