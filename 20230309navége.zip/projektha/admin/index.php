<?php
header("Location: admin.php");
exit();
?>