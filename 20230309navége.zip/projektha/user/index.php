<?php
header("Location:user.php");
exit();
?>